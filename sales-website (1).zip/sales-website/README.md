# Retail Sales Dashboard

A simple, static website that visualizes dummy retail sales data using plain HTML, CSS, and JavaScript (no build tools required).

## Files

```
sales-website/
├── index.html      # Page structure
├── style.css       # Styling
├── script.js       # Data loading, filtering, and chart rendering
└── data.json       # Dummy dataset (same data as the Excel file)
```

## Features

- Summary cards: total sales, total transactions, total quantity, average transaction value
- Filters by Region and Category
- Charts (via Chart.js from CDN):
  - Bar chart: Sales by Region
  - Doughnut chart: Sales by Category
  - Line chart: Sales trend over time
- Scrollable transaction detail table

## How to run in VS Code

1. Open the `sales-website` folder in VS Code (`File > Open Folder...`).
2. Install the **Live Server** extension (by Ritwick Dey) from the Extensions marketplace, if you don't have it yet.
3. Right-click `index.html` in the file explorer and choose **"Open with Live Server"**.
4. Your browser will open the dashboard automatically (usually at `http://127.0.0.1:5500`).

> Note: Opening `index.html` directly by double-clicking it (using the `file://` protocol) will likely fail to load `data.json` due to browser security restrictions (CORS). Always use Live Server or another local server.

### Alternative: run without the Live Server extension

If you have Python installed, you can also serve the folder from a terminal:

```bash
cd sales-website
python -m http.server 5500
```

Then open `http://localhost:5500` in your browser.

## Customizing the data

`data.json` is a plain array of objects with these fields:

```json
{
  "TransactionID": "TRX-0001",
  "Date": "2026-01-01",
  "CustomerName": "Customer 1",
  "Region": "North Region",
  "Category": "Electronics",
  "Product": "Wireless Mouse",
  "Quantity": 3,
  "UnitPrice": 15,
  "TotalSales": 45
}
```

Edit or replace this file with your own data (matching the same field names) and refresh the browser — the dashboard will update automatically.
