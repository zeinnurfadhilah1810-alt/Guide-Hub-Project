// ------------------------------------------------------------
// Retail Sales Dashboard - main script
// Loads data.json and renders summary cards, charts, and table
// ------------------------------------------------------------

let allData = [];
let filteredData = [];
let regionChart, categoryChart, trendChart;

const usd = (num) =>
  new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(num);

async function loadData() {
  const response = await fetch("data.json");
  if (!response.ok) {
    throw new Error("Failed to load data.json");
  }
  allData = await response.json();
  filteredData = [...allData];

  populateFilters();
  renderAll();
}

function populateFilters() {
  const regions = [...new Set(allData.map((d) => d.Region))].sort();
  const categories = [...new Set(allData.map((d) => d.Category))].sort();

  const regionSelect = document.getElementById("regionFilter");
  regions.forEach((r) => {
    const opt = document.createElement("option");
    opt.value = r;
    opt.textContent = r;
    regionSelect.appendChild(opt);
  });

  const categorySelect = document.getElementById("categoryFilter");
  categories.forEach((c) => {
    const opt = document.createElement("option");
    opt.value = c;
    opt.textContent = c;
    categorySelect.appendChild(opt);
  });

  regionSelect.addEventListener("change", applyFilters);
  categorySelect.addEventListener("change", applyFilters);
  document.getElementById("resetFilters").addEventListener("click", () => {
    regionSelect.value = "all";
    categorySelect.value = "all";
    applyFilters();
  });
}

function applyFilters() {
  const region = document.getElementById("regionFilter").value;
  const category = document.getElementById("categoryFilter").value;

  filteredData = allData.filter((d) => {
    const regionMatch = region === "all" || d.Region === region;
    const categoryMatch = category === "all" || d.Category === category;
    return regionMatch && categoryMatch;
  });

  renderAll();
}

function renderAll() {
  renderSummaryCards();
  renderTable();
  renderCharts();
}

function renderSummaryCards() {
  const totalSales = filteredData.reduce((sum, d) => sum + d.TotalSales, 0);
  const totalTransactions = filteredData.length;
  const totalQuantity = filteredData.reduce((sum, d) => sum + d.Quantity, 0);
  const avgTransaction = totalTransactions
    ? totalSales / totalTransactions
    : 0;

  document.getElementById("totalSales").textContent = usd(totalSales);
  document.getElementById("totalTransactions").textContent =
    totalTransactions;
  document.getElementById("totalQuantity").textContent = totalQuantity;
  document.getElementById("avgTransaction").textContent =
    usd(avgTransaction);
}

function renderTable() {
  const tbody = document.getElementById("tableBody");
  tbody.innerHTML = "";

  filteredData
    .slice()
    .sort((a, b) => new Date(a.Date) - new Date(b.Date))
    .forEach((row) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${row.TransactionID}</td>
        <td>${row.Date}</td>
        <td>${row.CustomerName}</td>
        <td>${row.Region}</td>
        <td>${row.Category}</td>
        <td>${row.Product}</td>
        <td>${row.Quantity}</td>
        <td>${usd(row.UnitPrice)}</td>
        <td>${usd(row.TotalSales)}</td>
      `;
      tbody.appendChild(tr);
    });
}

function groupSum(data, key) {
  const result = {};
  data.forEach((d) => {
    result[d[key]] = (result[d[key]] || 0) + d.TotalSales;
  });
  return result;
}

function renderCharts() {
  const regionData = groupSum(filteredData, "Region");
  const categoryData = groupSum(filteredData, "Category");

  // Trend: sum sales per date
  const trendMap = {};
  filteredData.forEach((d) => {
    trendMap[d.Date] = (trendMap[d.Date] || 0) + d.TotalSales;
  });
  const trendLabels = Object.keys(trendMap).sort(
    (a, b) => new Date(a) - new Date(b)
  );
  const trendValues = trendLabels.map((d) => trendMap[d]);

  const palette = [
    "#4472c4",
    "#70ad47",
    "#ffc000",
    "#ed7d31",
    "#a5a5a5",
    "#264478",
  ];

  // Destroy old chart instances before re-rendering (needed for filters)
  if (regionChart) regionChart.destroy();
  if (categoryChart) categoryChart.destroy();
  if (trendChart) trendChart.destroy();

  regionChart = new Chart(document.getElementById("regionChart"), {
    type: "bar",
    data: {
      labels: Object.keys(regionData),
      datasets: [
        {
          label: "Total Sales",
          data: Object.values(regionData),
          backgroundColor: palette[0],
          borderRadius: 4,
        },
      ],
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true } },
    },
  });

  categoryChart = new Chart(document.getElementById("categoryChart"), {
    type: "doughnut",
    data: {
      labels: Object.keys(categoryData),
      datasets: [
        {
          data: Object.values(categoryData),
          backgroundColor: palette,
        },
      ],
    },
    options: {
      responsive: true,
      plugins: { legend: { position: "bottom" } },
    },
  });

  trendChart = new Chart(document.getElementById("trendChart"), {
    type: "line",
    data: {
      labels: trendLabels,
      datasets: [
        {
          label: "Total Sales",
          data: trendValues,
          borderColor: palette[0],
          backgroundColor: "rgba(68, 114, 196, 0.15)",
          fill: true,
          tension: 0.3,
          pointRadius: 3,
        },
      ],
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true } },
    },
  });
}

loadData().catch((err) => {
  console.error(err);
  alert(
    "Could not load data.json. If you opened this file directly, please run it through a local server (e.g. VS Code Live Server extension)."
  );
});
